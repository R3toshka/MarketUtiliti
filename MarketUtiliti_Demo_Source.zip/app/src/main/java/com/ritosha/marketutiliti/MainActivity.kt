package com.ritosha.marketutiliti

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF061321)
private val Panel = Color(0xCC10243A)
private val Blue = Color(0xFF269BFF)
private val Muted = Color(0xFF9CB4CC)
private val Gold = Color(0xFFFFD15C)
private val Green = Color(0xFF63E6A2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MarketUtilitiApp() }
    }
}

data class ToolCard(val title: String, val subtitle: String, val icon: ImageVector, val tag: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarketUtilitiApp() {
    var page by remember { mutableStateOf("Главная") }
    var dark by remember { mutableStateOf(true) }
    var accent by remember { mutableStateOf("Синий") }
    val cards = listOf(
        ToolCard("Авто Бай", "Автопокупка по фильтрам", Icons.Default.ShoppingCart, "AUTO"),
        ToolCard("NFT Сканер", "Поиск лучших предложений", Icons.Default.Search, "SCAN"),
        ToolCard("Transfer", "Передача подарков", Icons.Default.Send, "TOOLS"),
        ToolCard("Analyzer", "Цены и редкость NFT", Icons.Default.BarChart, "ANALYTICS"),
        ToolCard("История", "Покупки и операции", Icons.Default.History, "LOGS"),
        ToolCard("Ссылки", "Избранные предложения", Icons.Default.Link, "SAVED")
    )
    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Navy, surface = Panel, onBackground = Color.White, onSurface = Color.White, secondary = Muted)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF07182B), Color(0xFF020811), Color(0xFF0B2541))))) {
            AnimatedContent(targetState = page, transitionSpec = {
                (slideInHorizontally(tween(230)) { it / 5 } + fadeIn(tween(230))) togetherWith
                    (slideOutHorizontally(tween(170)) { -it / 8 } + fadeOut(tween(170)))
            }, label = "page") { target ->
                when (target) {
                    "Главная" -> HomeScreen(cards, { page = it }, { page = "Настройки" })
                    "Настройки" -> SettingsScreen(dark, { dark = it }, accent, { accent = it }) { page = "Главная" }
                    else -> ToolScreen(target) { page = "Главная" }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(cards: List<ToolCard>, onOpen: (String) -> Unit, onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 18.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("✦  Market Utiliti", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Text("TELEGRAM NFT TOOLS", fontSize = 10.sp, letterSpacing = 3.sp, color = Muted)
            }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Настройки", tint = Color.White) }
        }
        Spacer(Modifier.height(15.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Surface(color = Color(0x3321C77A), shape = RoundedCornerShape(50)) {
                Text("●  ДЕМО-РЕЖИМ", color = Green, modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Text("Аккаунт не подключён", color = Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.height(15.dp))
        GlassPanel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Market dashboard", color = Muted, fontSize = 11.sp)
                    Text("Твой NFT-центр", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Все инструменты в одном месте", color = Muted, fontSize = 11.sp)
                }
                Icon(Icons.Default.AutoAwesome, null, tint = Blue, modifier = Modifier.size(42.dp))
            }
            Spacer(Modifier.height(13.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Metric("Сканер", "Ожидает")
                Metric("Авто Бай", "Выкл.")
                Metric("Баланс", "— ★")
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("ИНСТРУМЕНТЫ", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(9.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(11.dp), horizontalArrangement = Arrangement.spacedBy(11.dp), modifier = Modifier.weight(1f)) {
            items(cards) { item ->
                Surface(color = Panel, shape = RoundedCornerShape(21.dp), tonalElevation = 5.dp,
                    modifier = Modifier.fillMaxWidth().height(145.dp).clickable { onOpen(item.title) }) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = Color(0x33269BFF), shape = RoundedCornerShape(12.dp)) {
                                Icon(item.icon, null, tint = Blue, modifier = Modifier.padding(8.dp).size(22.dp))
                            }
                            Spacer(Modifier.weight(1f))
                            Text(item.tag, color = Color(0xFF6E8CA8), fontSize = 8.sp, letterSpacing = 1.sp)
                        }
                        Column {
                            Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Spacer(Modifier.height(3.dp))
                            Text(item.subtitle, color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Market Utiliti — независимый сторонний инструмент. Не является официальным приложением Telegram.", color = Muted, fontSize = 9.sp, lineHeight = 13.sp)
        Spacer(Modifier.height(5.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Конфиденциальность  ·  Поддержка", color = Muted, fontSize = 9.sp)
            Text("Ritosha ©", color = Muted, fontSize = 9.sp)
        }
    }
}

@Composable
fun Metric(label: String, value: String) {
    Surface(color = Color(0x221D9AFF), shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f)) {
        Column(Modifier.padding(9.dp)) {
            Text(label, color = Muted, fontSize = 9.sp)
            Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ToolScreen(title: String, onBack: () -> Unit) {
    var background by remember { mutableStateOf("Любой") }
    var model by remember { mutableStateOf("Любая") }
    var symbol by remember { mutableStateOf("Любой") }
    var maxStars by remember { mutableStateOf("250") }
    var budget by remember { mutableStateOf("1000") }
    var running by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf("Все") }
    var saved by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 17.dp, vertical = 9.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Назад", tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("MARKET UTILITI  /  DEMO", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
            }
            Icon(Icons.Default.MoreVert, null, tint = Muted)
        }
        Spacer(Modifier.height(10.dp))
        when (title) {
            "Авто Бай", "NFT Сканер" -> {
                Text(if (title == "Авто Бай") "Настрой автоматическую покупку" else "Подбери выгодные предложения", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(14.dp))
                GlassPanel {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Фильтры поиска", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("СБРОСИТЬ", color = Blue, fontSize = 9.sp, modifier = Modifier.clickable { background = "Любой"; model = "Любая"; symbol = "Любой"; maxStars = "250" })
                    }
                    Spacer(Modifier.height(12.dp))
                    FieldLabel("Цвет фона")
                    ChoiceField(background, { background = it }, listOf("Любой", "Black", "Blue", "Purple", "Red", "Green", "Gold"))
                    Spacer(Modifier.height(9.dp))
                    FieldLabel("Модель подарка")
                    ChoiceField(model, { model = it }, listOf("Любая", "Plush Pepe", "Durov's Cap", "Magic Potion", "Signet Ring", "Vintage Cigar"))
                    Spacer(Modifier.height(9.dp))
                    FieldLabel("Символ / форма")
                    ChoiceField(symbol, { symbol = it }, listOf("Любой", "Star", "Heart", "Diamond", "Flower"))
                    Spacer(Modifier.height(9.dp))
                    FieldLabel("Максимальная цена")
                    OutlinedTextField(value = maxStars, onValueChange = { maxStars = it }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        trailingIcon = { Text("★", color = Gold, modifier = Modifier.padding(end = 12.dp)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    if (title == "Авто Бай") {
                        Spacer(Modifier.height(9.dp))
                        FieldLabel("Общий бюджет")
                        OutlinedTextField(value = budget, onValueChange = { budget = it }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            trailingIcon = { Text("★", color = Gold, modifier = Modifier.padding(end = 12.dp)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                }
                Spacer(Modifier.height(13.dp))
                if (title == "NFT Сканер") {
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf("Все", "Дешёвые", "Редкие").forEach { tab ->
                            FilterChip(selected = selectedTab == tab, onClick = { selectedTab = tab }, label = { Text(tab) })
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    DemoOffer("Plush Pepe", "Модель: Emerald", "185 ★", "На 12% ниже средней")
                    DemoOffer("Durov's Cap", "Фон: Midnight", "220 ★", "Редкое предложение")
                }
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Button(onClick = { running = true }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(13.dp)) {
                        Icon(if (title == "Авто Бай") Icons.Default.PlayArrow else Icons.Default.Search, null)
                        Spacer(Modifier.width(5.dp)); Text(if (title == "Авто Бай") "Включить демо" else "Сканировать")
                    }
                    OutlinedButton(onClick = { running = false }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(13.dp)) {
                        Icon(Icons.Default.Stop, null); Spacer(Modifier.width(5.dp)); Text("Стоп")
                    }
                }
                Text(if (running) "Демо активно: реальные покупки и запросы не выполняются." else "Все действия здесь демонстрационные. Telegram не подключён.", color = if (running) Green else Muted, fontSize = 10.sp)
            }
            "Transfer" -> {
                GlassPanel {
                    Text("Передача подарка", color = Color.White, fontWeight = FontWeight.Bold)
                    FieldLabel("Ссылка или ID подарка")
                    var gift by remember { mutableStateOf("") }
                    OutlinedTextField(gift, { gift = it }, placeholder = { Text("https://t.me/nft/...") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Spacer(Modifier.height(10.dp)); FieldLabel("Получатель")
                    var recipient by remember { mutableStateOf("") }
                    OutlinedTextField(recipient, { recipient = it }, placeholder = { Text("@username") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(onClick = { saved = true }, modifier = Modifier.fillMaxWidth()) { Text("Проверить данные (демо)") }
                    if (saved) Text("Данные приняты в демо-режиме. Перевод не отправлен.", color = Green, fontSize = 11.sp)
                }
            }
            "Analyzer" -> {
                GlassPanel {
                    Text("Аналитика рынка", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Пример карточки NFT", color = Muted, fontSize = 11.sp)
                    DemoOffer("Plush Pepe", "Средняя цена за 24 ч.", "210 ★", "+4.8%")
                    DemoOffer("Magic Potion", "Индекс спроса", "Высокий", "Демо-данные")
                    DemoOffer("Durov's Cap", "Минимальная цена", "198 ★", "Обновление недоступно")
                }
            }
            "История" -> {
                GlassPanel {
                    Text("Последние операции", color = Color.White, fontWeight = FontWeight.Bold)
                    DemoOffer("Plush Pepe", "Покупка · демо", "185 ★", "Не совершалась")
                    DemoOffer("Vintage Cigar", "Сканирование", "—", "Сегодня · демо")
                    Text("Здесь будут отображаться реальные операции после подключения аккаунта.", color = Muted, fontSize = 11.sp)
                }
            }
            "Ссылки" -> {
                GlassPanel {
                    Text("Избранное", color = Color.White, fontWeight = FontWeight.Bold)
                    DemoOffer("Plush Pepe", "t.me/nft/PlushPepe-001", "185 ★", "Пример ссылки")
                    DemoOffer("Durov's Cap", "t.me/nft/DurovsCap-014", "220 ★", "Пример ссылки")
                    OutlinedButton(onClick = { saved = !saved }, modifier = Modifier.fillMaxWidth()) { Text(if (saved) "Избранное очищено (демо)" else "Очистить избранное") }
                }
            }
            else -> GlassPanel { Text("Раздел готовится", color = Color.White) }
        }
    }
}

@Composable fun FieldLabel(t: String) { Text(t, color = Muted, fontSize = 11.sp) }

@Composable
fun DemoOffer(name: String, desc: String, price: String, note: String) {
    Surface(color = Color(0x331B3855), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Color(0x33269BFF), shape = RoundedCornerShape(10.dp)) { Icon(Icons.Default.CardGiftcard, null, tint = Blue, modifier = Modifier.padding(9.dp).size(22.dp)) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(desc, color = Muted, fontSize = 10.sp)
                Text(note, color = Green, fontSize = 9.sp)
            }
            Text(price, color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
fun GlassPanel(content: @Composable ColumnScope.() -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(21.dp), tonalElevation = 4.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(15.dp), content = content)
    }
}

@Composable
fun ChoiceField(value: String, onChange: (String) -> Unit, options: List<String>) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
            Text(value, modifier = Modifier.weight(1f)); Icon(Icons.Default.ExpandMore, null)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onChange(option); expanded = false }) }
        }
    }
}

@Composable
fun SettingsScreen(dark: Boolean, onDarkChange: (Boolean) -> Unit, accent: String, onAccent: (String) -> Unit, onBack: () -> Unit) {
    var transparency by remember { mutableFloatStateOf(82f) }
    var notifications by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Назад", tint = Color.White) }
            Text("Настройки", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(13.dp)) {
            item { GlassPanel {
                Text("Оформление", color = Color.White, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Тёмная тема", color = Color.White, modifier = Modifier.weight(1f)); Switch(dark, onDarkChange) }
                FieldLabel("Акцентный цвет")
                ChoiceField(accent, onAccent, listOf("Синий", "Фиолетовый", "Бирюзовый"))
                FieldLabel("Прозрачность интерфейса · ${transparency.toInt()}%")
                Slider(value = transparency, onValueChange = { transparency = it }, valueRange = 40f..100f)
                Text("Шрифт и фон появятся в следующих версиях.", color = Muted, fontSize = 11.sp)
            } }
            item { GlassPanel {
                Text("Уведомления", color = Color.White, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Уведомления приложения", color = Color.White, modifier = Modifier.weight(1f)); Switch(notifications, { notifications = it }) }
            } }
            item { GlassPanel {
                Text("Безопасность и аккаунт", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Telegram не подключён. В полной версии сессия будет храниться локально в защищённом виде.", color = Muted, fontSize = 11.sp)
                Text("Не вводи коды Telegram в демо-версии.", color = Gold, fontSize = 11.sp)
            } }
            item { GlassPanel {
                Text("О приложении", color = Color.White, fontWeight = FontWeight.Bold)
                Text("MarketUtiliti · Demo build", color = Muted, fontSize = 11.sp)
                Text("Независимый сторонний инструмент от Ritosha.", color = Muted, fontSize = 11.sp)
            } }
        }
    }
}
